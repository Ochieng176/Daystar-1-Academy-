import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LoginModal } from "@/components/login-modal";
import { Chatbot } from "@/components/chatbot";
import { MapLocation } from "@/components/map-location";
import { 
  GraduationCap, 
  Users, 
  BookOpen, 
  Trophy, 
  Target, 
  Eye, 
  Star, 
  History,
  Menu,
  X,
  Phone,
  Mail,
  Clock,
  Check,
  Baby,
  Laptop
} from "lucide-react";

export default function Landing() {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg fixed w-full top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <GraduationCap className="text-blue-600 text-2xl mr-2 h-8 w-8" />
                <span className="font-bold text-xl text-gray-800">FPFK DAYSTAR ACADEMY</span>
              </div>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-blue-600 transition duration-200">Home</button>
              <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-blue-600 transition duration-200">About</button>
              <button onClick={() => scrollToSection('cbc')} className="text-gray-700 hover:text-blue-600 transition duration-200">CBC</button>
              <button onClick={() => scrollToSection('location')} className="text-gray-700 hover:text-blue-600 transition duration-200">Location</button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-blue-600 transition duration-200">Contact</button>
              <Button 
                onClick={() => setIsLoginModalOpen(true)}
                className="bg-blue-600 text-white px-6 py-2 hover:bg-blue-700 transition duration-200"
              >
                Login
              </Button>
            </div>
            
            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center">
              <Button
                variant="ghost"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-gray-700"
              >
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button onClick={() => scrollToSection('home')} className="block px-3 py-2 text-gray-700 w-full text-left">Home</button>
              <button onClick={() => scrollToSection('about')} className="block px-3 py-2 text-gray-700 w-full text-left">About</button>
              <button onClick={() => scrollToSection('cbc')} className="block px-3 py-2 text-gray-700 w-full text-left">CBC</button>
              <button onClick={() => scrollToSection('location')} className="block px-3 py-2 text-gray-700 w-full text-left">Location</button>
              <button onClick={() => scrollToSection('contact')} className="block px-3 py-2 text-gray-700 w-full text-left">Contact</button>
              <button onClick={() => setIsLoginModalOpen(true)} className="block w-full text-left px-3 py-2 text-blue-600 font-medium">Login</button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-16 bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Welcome to<br />
                <span className="text-yellow-400">FPFK DAYSTAR ACADEMY</span>
              </h1>
              <p className="text-xl mb-4 text-blue-100">Where Quality Is Nurtured</p>
              <p className="text-lg mb-8 text-blue-100 leading-relaxed">
                Providing excellent education with emphasis on moral uprightness and positive attitude towards life since 2012.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={() => setIsLoginModalOpen(true)}
                  className="bg-yellow-500 text-black px-8 py-3 hover:bg-yellow-400 transition duration-200"
                >
                  Access Portal
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => scrollToSection('about')}
                  className="border-2 border-white text-white px-8 py-3 hover:bg-white hover:text-blue-600 transition duration-200"
                >
                  Learn More
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1580582932707-520aed937b7b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Modern school building" 
                className="rounded-xl shadow-2xl w-full h-auto" 
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-lg shadow-xl">
                <div className="text-blue-600 font-bold text-2xl">2012</div>
                <div className="text-gray-600">Established</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">About Our Academy</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Founded in 2012, FPFK Daystar Academy has been at the forefront of quality education in Busia County.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <Card className="bg-gradient-to-br from-blue-600 to-blue-700 text-white">
              <CardContent className="p-8">
                <History className="h-8 w-8 mb-4 text-yellow-400" />
                <h3 className="text-xl font-bold mb-3">Our History</h3>
                <p className="text-blue-100">
                  Established in 2012, we have grown from a small community school to a leading educational institution in Busia County.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-600 to-green-700 text-white">
              <CardContent className="p-8">
                <Target className="h-8 w-8 mb-4 text-yellow-400" />
                <h3 className="text-xl font-bold mb-3">Our Mission</h3>
                <p className="text-green-100">
                  To provide Quality, Excellent Education to learners with emphasis on key virtues, moral uprightness & positive attitude towards life.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white">
              <CardContent className="p-8">
                <Eye className="h-8 w-8 mb-4 text-white" />
                <h3 className="text-xl font-bold mb-3">Our Vision</h3>
                <p className="text-yellow-100">
                  To be the leading institution of excellence in teaching & learning for Quality Results.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-600 to-purple-800 text-white">
              <CardContent className="p-8">
                <Star className="h-8 w-8 mb-4 text-yellow-400" />
                <h3 className="text-xl font-bold mb-3">Our Motto</h3>
                <p className="text-purple-100">
                  "Where Quality Is Nurtured" - Excellence in every aspect of education and character development.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-white text-xl h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Expert Faculty</h3>
              <p className="text-gray-600">Qualified and experienced teachers committed to excellence.</p>
            </div>
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="text-white text-xl h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">CBC Curriculum</h3>
              <p className="text-gray-600">Full implementation of Competency-Based Curriculum.</p>
            </div>
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="text-white text-xl h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-2">Quality Results</h3>
              <p className="text-gray-600">Consistent academic excellence and character development.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CBC Section */}
      <section id="cbc" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Competency-Based Curriculum (CBC)</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We have fully implemented the CBC system to nurture well-rounded learners with 21st-century skills.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Baby className="text-blue-600 text-xl h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-gray-800">Early Years Education</h3>
                <p className="text-gray-600 mb-4">PP1 & PP2 programs focusing on foundational skills and holistic development.</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Play-based learning</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Language development</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Numeracy skills</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <BookOpen className="text-green-600 text-xl h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-gray-800">Lower Primary</h3>
                <p className="text-gray-600 mb-4">Grade 1-3 curriculum with emphasis on literacy, numeracy, and life skills.</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Integrated learning</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Local language support</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Creative arts</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4">
                  <GraduationCap className="text-yellow-600 text-xl h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-gray-800">Upper Primary</h3>
                <p className="text-gray-600 mb-4">Grade 4-6 with specialized subjects and competency development.</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Subject specialization</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Critical thinking</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Digital literacy</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <Check className="text-purple-600 text-xl h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-gray-800">Assessment Methods</h3>
                <p className="text-gray-600 mb-4">Continuous assessment focusing on competency development.</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Formative assessment</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Portfolio development</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Project-based evaluation</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                  <Users className="text-red-600 text-xl h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-gray-800">Co-curricular Activities</h3>
                <p className="text-gray-600 mb-4">Sports, arts, and clubs to develop diverse talents and interests.</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Sports programs</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Music & drama</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Science club</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <Laptop className="text-indigo-600 text-xl h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-gray-800">Learning Resources</h3>
                <p className="text-gray-600 mb-4">Modern facilities and digital resources to support CBC implementation.</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Digital classrooms</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Library resources</li>
                  <li className="flex items-center"><Check className="text-green-600 mr-2 h-4 w-4" />Science laboratory</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Location Section */}
      <MapLocation />

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Get In Touch</h2>
            <p className="text-xl text-gray-600">We'd love to hear from you. Contact us for admissions or inquiries.</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold mb-6 text-gray-800">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                    <Phone className="text-white h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Phone</h4>
                    <p className="text-gray-600">+254 XXX XXX XXX</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mr-4">
                    <Mail className="text-white h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Email</h4>
                    <p className="text-gray-600">info@fpfkdaystar.ac.ke</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center mr-4">
                    <Clock className="text-white h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Office Hours</h4>
                    <p className="text-gray-600">Monday - Friday: 8:00 AM - 4:00 PM</p>
                  </div>
                </div>
              </div>
            </div>
            
            <Card className="shadow-lg">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold mb-6">Send us a Message</h3>
                <form className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <Input type="text" placeholder="First Name" />
                    <Input type="text" placeholder="Last Name" />
                  </div>
                  <Input type="email" placeholder="Email Address" />
                  <Input type="tel" placeholder="Phone Number" />
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Inquiry Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admissions">Admissions</SelectItem>
                      <SelectItem value="general">General Information</SelectItem>
                      <SelectItem value="cbc">CBC Curriculum</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <Textarea rows={4} placeholder="Your Message" />
                  <Button type="submit" className="w-full bg-blue-600 text-white py-3 hover:bg-blue-700 transition duration-200">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <GraduationCap className="text-yellow-400 text-2xl mr-2 h-8 w-8" />
                <span className="font-bold text-xl">FPFK DAYSTAR ACADEMY</span>
              </div>
              <p className="text-gray-300 mb-4">Where Quality Is Nurtured</p>
              <p className="text-gray-400 text-sm">Providing excellent education since 2012 in Lukolis, Busia County, Kenya.</p>
            </div>
            
            <div>
              <h3 className="font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-300">
                <li><button onClick={() => scrollToSection('about')} className="hover:text-yellow-400 transition duration-200">About Us</button></li>
                <li><button onClick={() => scrollToSection('cbc')} className="hover:text-yellow-400 transition duration-200">CBC Curriculum</button></li>
                <li><button onClick={() => scrollToSection('location')} className="hover:text-yellow-400 transition duration-200">Location</button></li>
                <li><button onClick={() => scrollToSection('contact')} className="hover:text-yellow-400 transition duration-200">Contact</button></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-300">
                <li><span className="hover:text-yellow-400 transition duration-200">Admissions</span></li>
                <li><span className="hover:text-yellow-400 transition duration-200">Academic Calendar</span></li>
                <li><span className="hover:text-yellow-400 transition duration-200">Online Resources</span></li>
                <li><span className="hover:text-yellow-400 transition duration-200">Parent Portal</span></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-4">Contact Info</h3>
              <div className="space-y-2 text-gray-300">
                <p className="flex items-center"><Phone className="mr-2 h-4 w-4" />Lukolis, Busia County</p>
                <p className="flex items-center"><Mail className="mr-2 h-4 w-4" />P.O BOX 65-50403 AMUKURA</p>
                <p className="flex items-center"><Phone className="mr-2 h-4 w-4" />+254 XXX XXX XXX</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 FPFK Daystar Academy. All rights reserved. | Where Quality Is Nurtured</p>
          </div>
        </div>
      </footer>

      {/* Login Modal */}
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)}
        onOpenChatbot={() => setIsChatbotOpen(true)}
      />

      {/* Chatbot */}
      <Chatbot />
    </div>
  );
}
