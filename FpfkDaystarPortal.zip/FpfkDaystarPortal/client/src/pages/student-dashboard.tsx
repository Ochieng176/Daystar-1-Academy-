import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  BookOpen, 
  Trophy, 
  Calendar, 
  FileText,
  GraduationCap,
  LogOut,
  Star,
  Clock,
  Target
} from "lucide-react";

export default function StudentDashboard() {
  const { user } = useAuth();

  // Fetch CBC resources
  const { data: cbcResources, isLoading: resourcesLoading } = useQuery({
    queryKey: ['/api/cbc-resources'],
    retry: false,
  });

  // Fetch announcements
  const { data: announcements, isLoading: announcementsLoading } = useQuery({
    queryKey: ['/api/announcements'],
    retry: false,
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-purple-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Student Dashboard</h1>
                <p className="text-gray-600">Welcome back, {user?.firstName || 'Student'}!</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              onClick={() => window.location.href = '/api/logout'}
              className="flex items-center space-x-2"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Student Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Subjects</p>
                  <p className="text-2xl font-bold">8</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Trophy className="h-8 w-8 text-yellow-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Average Grade</p>
                  <p className="text-2xl font-bold">85%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Calendar className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Attendance</p>
                  <p className="text-2xl font-bold">95%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <FileText className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Assignments</p>
                  <p className="text-2xl font-bold">12</p>
                  <p className="text-xs text-gray-500">Pending</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Learning Progress */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="h-5 w-5 mr-2" />
                Learning Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">Mathematics</span>
                    <span className="text-sm text-gray-600">92%</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">English</span>
                    <span className="text-sm text-gray-600">88%</span>
                  </div>
                  <Progress value={88} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">Science</span>
                    <span className="text-sm text-gray-600">85%</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">Social Studies</span>
                    <span className="text-sm text-gray-600">90%</span>
                  </div>
                  <Progress value={90} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">Kiswahili</span>
                    <span className="text-sm text-gray-600">78%</span>
                  </div>
                  <Progress value={78} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Announcements */}
          <Card>
            <CardHeader>
              <CardTitle>School Updates</CardTitle>
            </CardHeader>
            <CardContent>
              {announcementsLoading ? (
                <p>Loading announcements...</p>
              ) : (
                <div className="space-y-4">
                  {announcements?.slice(0, 3).map((announcement: any) => (
                    <div key={announcement.id} className="border-l-4 border-purple-500 pl-4">
                      <h4 className="font-semibold text-gray-900">{announcement.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{announcement.content}</p>
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(announcement.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                  {announcements?.length === 0 && (
                    <p className="text-gray-500 text-center py-4">No announcements yet.</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
          {/* Today's Schedule */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Today's Classes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                  <div>
                    <span className="font-semibold">Mathematics</span>
                    <p className="text-sm text-gray-600">Mr. Johnson</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline">8:00 AM</Badge>
                    <p className="text-xs text-gray-500">Room 4A</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <div>
                    <span className="font-semibold">English</span>
                    <p className="text-sm text-gray-600">Mrs. Smith</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline">10:00 AM</Badge>
                    <p className="text-xs text-gray-500">Room 4B</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                  <div>
                    <span className="font-semibold">Science</span>
                    <p className="text-sm text-gray-600">Mr. Brown</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline">2:00 PM</Badge>
                    <p className="text-xs text-gray-500">Lab 1</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Achievements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Star className="h-5 w-5 mr-2" />
                Recent Achievements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center p-3 bg-yellow-50 rounded-lg">
                  <Trophy className="h-8 w-8 text-yellow-600 mr-3" />
                  <div>
                    <span className="font-semibold">Mathematics Excellence</span>
                    <p className="text-sm text-gray-600">Scored 95% in last test</p>
                  </div>
                </div>
                
                <div className="flex items-center p-3 bg-green-50 rounded-lg">
                  <Star className="h-8 w-8 text-green-600 mr-3" />
                  <div>
                    <span className="font-semibold">Perfect Attendance</span>
                    <p className="text-sm text-gray-600">No absences this month</p>
                  </div>
                </div>
                
                <div className="flex items-center p-3 bg-blue-50 rounded-lg">
                  <BookOpen className="h-8 w-8 text-blue-600 mr-3" />
                  <div>
                    <span className="font-semibold">Reading Champion</span>
                    <p className="text-sm text-gray-600">Completed 5 books this term</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Available Resources */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Learning Resources</CardTitle>
          </CardHeader>
          <CardContent>
            {resourcesLoading ? (
              <p>Loading resources...</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {cbcResources?.slice(0, 6).map((resource: any) => (
                  <div key={resource.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                    <h4 className="font-semibold text-gray-900">{resource.title}</h4>
                    <p className="text-sm text-gray-600 mt-1">{resource.description}</p>
                    <div className="flex space-x-2 mt-3">
                      <Badge variant="outline">{resource.grade}</Badge>
                      <Badge variant="outline">{resource.subject}</Badge>
                    </div>
                    <Button size="sm" className="w-full mt-3" variant="outline">
                      Access Resource
                    </Button>
                  </div>
                ))}
                {cbcResources?.length === 0 && (
                  <p className="text-gray-500 text-center py-4 col-span-full">No resources available yet.</p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
