import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  BookOpen, 
  Users, 
  FileText, 
  Calendar,
  GraduationCap,
  LogOut,
  Download,
  Eye
} from "lucide-react";

export default function TeacherDashboard() {
  const { user } = useAuth();

  // Fetch CBC resources
  const { data: cbcResources, isLoading: resourcesLoading } = useQuery({
    queryKey: ['/api/cbc-resources'],
    retry: false,
  });

  // Fetch announcements
  const { data: announcements, isLoading: announcementsLoading } = useQuery({
    queryKey: ['/api/announcements'],
    retry: false,
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Teacher Dashboard</h1>
                <p className="text-gray-600">Welcome back, {user?.firstName || 'Teacher'}</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              onClick={() => window.location.href = '/api/logout'}
              className="flex items-center space-x-2"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">My Students</p>
                  <p className="text-2xl font-bold">32</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">CBC Resources</p>
                  <p className="text-2xl font-bold">{cbcResources?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <FileText className="h-8 w-8 text-orange-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Lesson Plans</p>
                  <p className="text-2xl font-bold">15</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Calendar className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">This Week</p>
                  <p className="text-2xl font-bold">8</p>
                  <p className="text-xs text-gray-500">Classes</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* CBC Resources */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BookOpen className="h-5 w-5 mr-2" />
                CBC Resources
              </CardTitle>
            </CardHeader>
            <CardContent>
              {resourcesLoading ? (
                <p>Loading resources...</p>
              ) : (
                <div className="space-y-4">
                  {cbcResources?.slice(0, 6).map((resource: any) => (
                    <div key={resource.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{resource.title}</h4>
                          <p className="text-sm text-gray-600 mt-1">{resource.description}</p>
                          <div className="flex space-x-2 mt-2">
                            <Badge variant="outline">{resource.grade}</Badge>
                            <Badge variant="outline">{resource.subject}</Badge>
                            <Badge variant="secondary">{resource.resourceType}</Badge>
                          </div>
                        </div>
                        <div className="flex space-x-2 ml-4">
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {cbcResources?.length === 0 && (
                    <p className="text-gray-500 text-center py-4">No resources available yet.</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Announcements */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Announcements</CardTitle>
            </CardHeader>
            <CardContent>
              {announcementsLoading ? (
                <p>Loading announcements...</p>
              ) : (
                <div className="space-y-4">
                  {announcements?.slice(0, 5).map((announcement: any) => (
                    <div key={announcement.id} className="border-l-4 border-green-500 pl-4">
                      <h4 className="font-semibold text-gray-900">{announcement.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{announcement.content}</p>
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(announcement.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                  {announcements?.length === 0 && (
                    <p className="text-gray-500 text-center py-4">No announcements yet.</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Today's Schedule */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Today's Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="border rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold">Mathematics</span>
                  <Badge variant="outline">Grade 4</Badge>
                </div>
                <p className="text-sm text-gray-600">8:00 AM - 9:30 AM</p>
                <p className="text-sm text-gray-500">Room 4A</p>
              </div>
              
              <div className="border rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold">English</span>
                  <Badge variant="outline">Grade 5</Badge>
                </div>
                <p className="text-sm text-gray-600">10:00 AM - 11:30 AM</p>
                <p className="text-sm text-gray-500">Room 5B</p>
              </div>
              
              <div className="border rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold">Science</span>
                  <Badge variant="outline">Grade 6</Badge>
                </div>
                <p className="text-sm text-gray-600">2:00 PM - 3:30 PM</p>
                <p className="text-sm text-gray-500">Lab 1</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
