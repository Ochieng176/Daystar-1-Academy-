import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Settings, 
  Wrench, 
  Calendar, 
  MessageSquare,
  GraduationCap,
  LogOut,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  Users,
  Building
} from "lucide-react";

export default function WorkerDashboard() {
  const { user } = useAuth();

  // Fetch announcements
  const { data: announcements, isLoading: announcementsLoading } = useQuery({
    queryKey: ['/api/announcements'],
    retry: false,
  });

  // Mock maintenance data - in real implementation, this would come from API
  const maintenanceTasks = [
    { id: 1, task: "Clean Grade 4 classrooms", status: "completed", priority: "medium", dueDate: "Today" },
    { id: 2, task: "Fix leaking faucet in washroom", status: "pending", priority: "high", dueDate: "Tomorrow" },
    { id: 3, task: "Mow school compound grass", status: "in-progress", priority: "low", dueDate: "This week" },
    { id: 4, task: "Repair broken window in library", status: "pending", priority: "high", dueDate: "Today" },
    { id: 5, task: "Clean science laboratory", status: "completed", priority: "medium", dueDate: "Yesterday" },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const completedTasks = maintenanceTasks.filter(task => task.status === 'completed').length;
  const pendingTasks = maintenanceTasks.filter(task => task.status === 'pending').length;
  const inProgressTasks = maintenanceTasks.filter(task => task.status === 'in-progress').length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-gray-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Worker Dashboard</h1>
                <p className="text-gray-600">Welcome back, {user?.firstName || 'Worker'}</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              onClick={() => window.location.href = '/api/logout'}
              className="flex items-center space-x-2"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Completed Today</p>
                  <p className="text-2xl font-bold">{completedTasks}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Clock className="h-8 w-8 text-yellow-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">In Progress</p>
                  <p className="text-2xl font-bold">{inProgressTasks}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <AlertTriangle className="h-8 w-8 text-red-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Pending</p>
                  <p className="text-2xl font-bold">{pendingTasks}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Wrench className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Total Tasks</p>
                  <p className="text-2xl font-bold">{maintenanceTasks.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Today's Tasks */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="h-5 w-5 mr-2" />
                Maintenance Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {maintenanceTasks.map((task) => (
                  <div key={task.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900">{task.task}</h4>
                        <div className="flex items-center space-x-4 mt-2">
                          <Badge className={getStatusColor(task.status)}>
                            {task.status}
                          </Badge>
                          <span className={`text-sm font-medium ${getPriorityColor(task.priority)}`}>
                            {task.priority} priority
                          </span>
                          <span className="text-sm text-gray-500">Due: {task.dueDate}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2 ml-4">
                        {task.status === 'pending' && (
                          <Button size="sm" variant="outline">
                            Start
                          </Button>
                        )}
                        {task.status === 'in-progress' && (
                          <Button size="sm">
                            Complete
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* School Updates */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                School Updates
              </CardTitle>
            </CardHeader>
            <CardContent>
              {announcementsLoading ? (
                <p>Loading announcements...</p>
              ) : (
                <div className="space-y-4">
                  {announcements?.slice(0, 4).map((announcement: any) => (
                    <div key={announcement.id} className="border-l-4 border-gray-500 pl-4">
                      <h4 className="font-semibold text-gray-900">{announcement.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{announcement.content}</p>
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(announcement.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                  {announcements?.length === 0 && (
                    <p className="text-gray-500 text-center py-4">No announcements yet.</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Work Areas */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Building className="h-5 w-5 mr-2" />
              Work Areas & Responsibilities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="border rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <Building className="h-6 w-6 text-blue-600 mr-2" />
                  <h3 className="font-semibold">Classrooms</h3>
                </div>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Daily cleaning</li>
                  <li>• Furniture maintenance</li>
                  <li>• Whiteboard cleaning</li>
                  <li>• Window cleaning</li>
                </ul>
              </div>

              <div className="border rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <Settings className="h-6 w-6 text-green-600 mr-2" />
                  <h3 className="font-semibold">Facilities</h3>
                </div>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Plumbing repairs</li>
                  <li>• Electrical maintenance</li>
                  <li>• HVAC systems</li>
                  <li>• Security systems</li>
                </ul>
              </div>

              <div className="border rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <Users className="h-6 w-6 text-purple-600 mr-2" />
                  <h3 className="font-semibold">Grounds</h3>
                </div>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Landscaping</li>
                  <li>• Playground maintenance</li>
                  <li>• Waste management</li>
                  <li>• Safety inspections</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Button className="h-20 flex flex-col items-center justify-center space-y-2">
                <AlertTriangle className="h-6 w-6" />
                <span>Report Issue</span>
              </Button>
              
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                <Calendar className="h-6 w-6" />
                <span>Schedule Task</span>
              </Button>
              
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                <FileText className="h-6 w-6" />
                <span>Submit Report</span>
              </Button>
              
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                <Wrench className="h-6 w-6" />
                <span>Request Supplies</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
