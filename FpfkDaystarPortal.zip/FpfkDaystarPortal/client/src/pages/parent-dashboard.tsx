import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  BookOpen, 
  Calendar, 
  MessageSquare,
  GraduationCap,
  LogOut,
  TrendingUp,
  Clock,
  Award,
  FileText
} from "lucide-react";

export default function ParentDashboard() {
  const { user } = useAuth();

  // Fetch announcements
  const { data: announcements, isLoading: announcementsLoading } = useQuery({
    queryKey: ['/api/announcements'],
    retry: false,
  });

  // Mock student data - in real implementation, this would come from API
  const studentData = {
    name: "John Doe",
    grade: "Grade 5",
    studentId: "FD2024001",
    attendance: 94,
    averageGrade: 87,
    subjects: [
      { name: "Mathematics", grade: 92, progress: 92 },
      { name: "English", grade: 88, progress: 88 },
      { name: "Science", grade: 85, progress: 85 },
      { name: "Social Studies", grade: 90, progress: 90 },
      { name: "Kiswahili", grade: 82, progress: 82 },
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-orange-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Parent Dashboard</h1>
                <p className="text-gray-600">Welcome back, {user?.firstName || 'Parent'}</p>
              </div>
            </div>
            <Button 
              variant="outline" 
              onClick={() => window.location.href = '/api/logout'}
              className="flex items-center space-x-2"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Student Overview */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Student Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div>
                <p className="text-sm text-gray-600">Student Name</p>
                <p className="text-lg font-semibold">{studentData.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Grade</p>
                <p className="text-lg font-semibold">{studentData.grade}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Student ID</p>
                <p className="text-lg font-semibold">{studentData.studentId}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Academic Year</p>
                <p className="text-lg font-semibold">2024</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Average Grade</p>
                  <p className="text-2xl font-bold">{studentData.averageGrade}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Calendar className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Attendance</p>
                  <p className="text-2xl font-bold">{studentData.attendance}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <BookOpen className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Subjects</p>
                  <p className="text-2xl font-bold">{studentData.subjects.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Award className="h-8 w-8 text-yellow-600" />
                <div className="ml-4">
                  <p className="text-sm text-gray-600">Rank</p>
                  <p className="text-2xl font-bold">3rd</p>
                  <p className="text-xs text-gray-500">in class</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Academic Progress */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                Academic Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {studentData.subjects.map((subject, index) => (
                  <div key={index}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">{subject.name}</span>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">{subject.grade}%</Badge>
                      </div>
                    </div>
                    <Progress value={subject.progress} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* School Announcements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                School Updates
              </CardTitle>
            </CardHeader>
            <CardContent>
              {announcementsLoading ? (
                <p>Loading announcements...</p>
              ) : (
                <div className="space-y-4">
                  {announcements?.slice(0, 4).map((announcement: any) => (
                    <div key={announcement.id} className="border-l-4 border-orange-500 pl-4">
                      <h4 className="font-semibold text-gray-900">{announcement.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{announcement.content}</p>
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(announcement.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                  {announcements?.length === 0 && (
                    <p className="text-gray-500 text-center py-4">No announcements yet.</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Recent Activities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center">
                    <Award className="h-6 w-6 text-green-600 mr-3" />
                    <div>
                      <span className="font-semibold">Mathematics Test</span>
                      <p className="text-sm text-gray-600">Scored 92% - Excellent!</p>
                    </div>
                  </div>
                  <Badge variant="outline">2 days ago</Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center">
                    <FileText className="h-6 w-6 text-blue-600 mr-3" />
                    <div>
                      <span className="font-semibold">Science Project</span>
                      <p className="text-sm text-gray-600">Submitted on time</p>
                    </div>
                  </div>
                  <Badge variant="outline">5 days ago</Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                  <div className="flex items-center">
                    <Calendar className="h-6 w-6 text-yellow-600 mr-3" />
                    <div>
                      <span className="font-semibold">Perfect Attendance</span>
                      <p className="text-sm text-gray-600">Full week attendance</p>
                    </div>
                  </div>
                  <Badge variant="outline">1 week ago</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Events */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Upcoming Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border-l-4 border-blue-500 pl-4">
                  <h4 className="font-semibold">Parent-Teacher Meeting</h4>
                  <p className="text-sm text-gray-600">Discussion about term progress</p>
                  <p className="text-xs text-gray-400 mt-1">Next Friday, 2:00 PM</p>
                </div>
                
                <div className="border-l-4 border-green-500 pl-4">
                  <h4 className="font-semibold">Science Fair</h4>
                  <p className="text-sm text-gray-600">Annual school science exhibition</p>
                  <p className="text-xs text-gray-400 mt-1">Next Month, TBD</p>
                </div>
                
                <div className="border-l-4 border-purple-500 pl-4">
                  <h4 className="font-semibold">Sports Day</h4>
                  <p className="text-sm text-gray-600">Inter-house sports competition</p>
                  <p className="text-xs text-gray-400 mt-1">End of Term</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Communication Section */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button className="h-20 flex flex-col items-center justify-center space-y-2">
                <MessageSquare className="h-6 w-6" />
                <span>Message Teacher</span>
              </Button>
              
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                <Calendar className="h-6 w-6" />
                <span>Schedule Meeting</span>
              </Button>
              
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                <FileText className="h-6 w-6" />
                <span>View Reports</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
