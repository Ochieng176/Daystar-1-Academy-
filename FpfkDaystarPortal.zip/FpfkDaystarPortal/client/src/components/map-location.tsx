import { MapPin, Phone, Clock, Navigation } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export function MapLocation() {
  const schoolInfo = {
    location: "Lukolis, Busia County, Kenya",
    postalAddress: "P.O BOX 65-50403 AMUKURA",
    phone: "+254 XXX XXX XXX",
    hours: "Monday - Friday: 7:00 AM - 5:00 PM"
  };

  const handleGetDirections = () => {
    // Open Google Maps with school location
    const query = encodeURIComponent("Lukolis, Busia County, Kenya");
    window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
  };

  return (
    <section id="location" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Find Us</h2>
          <p className="text-xl text-gray-600">Located in Lukolis, Busia County, Kenya</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-bold mb-6 text-gray-800">School Location</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <MapPin className="text-blue-600 text-xl mr-4 mt-1 h-5 w-5" />
                <div>
                  <h4 className="font-semibold text-gray-800">Physical Address</h4>
                  <p className="text-gray-600">{schoolInfo.location}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <MapPin className="text-blue-600 text-xl mr-4 mt-1 h-5 w-5" />
                <div>
                  <h4 className="font-semibold text-gray-800">Postal Address</h4>
                  <p className="text-gray-600">{schoolInfo.postalAddress}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Phone className="text-blue-600 text-xl mr-4 mt-1 h-5 w-5" />
                <div>
                  <h4 className="font-semibold text-gray-800">Contact</h4>
                  <p className="text-gray-600">{schoolInfo.phone}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Clock className="text-blue-600 text-xl mr-4 mt-1 h-5 w-5" />
                <div>
                  <h4 className="font-semibold text-gray-800">School Hours</h4>
                  <p className="text-gray-600">{schoolInfo.hours}</p>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <Button 
                onClick={handleGetDirections}
                className="bg-blue-600 text-white px-6 py-3 hover:bg-blue-700 transition duration-200"
              >
                <Navigation className="mr-2 h-4 w-4" />
                Get Directions
              </Button>
            </div>
          </div>
          
          <div>
            <Card className="h-96 relative overflow-hidden">
              <CardContent className="p-0 h-full">
                <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
                  <div className="text-center">
                    <MapPin className="h-16 w-16 text-gray-400 mb-4 mx-auto" />
                    <h4 className="text-lg font-semibold text-gray-600 mb-2">Interactive Map</h4>
                    <p className="text-gray-500 mb-4">Lukolis, Busia County, Kenya</p>
                    <div className="flex items-center justify-center">
                      <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse"></div>
                      <p className="text-sm text-red-600 ml-2">FPFK Daystar Academy</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <p className="text-sm text-gray-500 mt-4 text-center">
              Click on the map to view in full screen or get directions
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
