import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  UserRoundCheck, 
  GraduationCap, 
  Users, 
  BookOpen, 
  Settings,
  Bot
} from "lucide-react";

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenChatbot: () => void;
}

interface RoleCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: string;
  onClick: () => void;
}

function RoleCard({ icon, title, description, color, onClick }: RoleCardProps) {
  return (
    <Card 
      className={`cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1 ${color}`}
      onClick={onClick}
    >
      <CardContent className="p-6 text-white">
        <div className="mb-4">{icon}</div>
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-sm opacity-90">{description}</p>
      </CardContent>
    </Card>
  );
}

export function LoginModal({ isOpen, onClose, onOpenChatbot }: LoginModalProps) {
  const [showRoleSelection, setShowRoleSelection] = useState(true);

  const handleRoleSelect = (role: string) => {
    if (role === 'chatbot') {
      onClose();
      onOpenChatbot();
    } else {
      // Navigate to login route for the specific role
      window.location.href = '/api/login';
    }
  };

  const roles = [
    {
      key: 'administration',
      icon: <UserRoundCheck className="h-8 w-8" />,
      title: 'Administration',
      description: 'School management and administrative functions',
      color: 'bg-gradient-to-br from-blue-500 to-blue-700'
    },
    {
      key: 'teacher',
      icon: <BookOpen className="h-8 w-8" />,
      title: 'Teacher',
      description: 'Classroom management and student assessment',
      color: 'bg-gradient-to-br from-green-500 to-green-700'
    },
    {
      key: 'student',
      icon: <GraduationCap className="h-8 w-8" />,
      title: 'Student',
      description: 'Access learning materials and assignments',
      color: 'bg-gradient-to-br from-purple-500 to-purple-700'
    },
    {
      key: 'parent',
      icon: <Users className="h-8 w-8" />,
      title: 'Parent',
      description: "Monitor child's progress and communicate",
      color: 'bg-gradient-to-br from-orange-500 to-orange-700'
    },
    {
      key: 'worker',
      icon: <Settings className="h-8 w-8" />,
      title: 'School Worker',
      description: 'Support staff and maintenance functions',
      color: 'bg-gradient-to-br from-gray-500 to-gray-700'
    },
    {
      key: 'chatbot',
      icon: <Bot className="h-8 w-8" />,
      title: 'ChogeaX Bot',
      description: 'AI consultation and system support',
      color: 'bg-gradient-to-br from-indigo-500 to-indigo-700'
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold text-gray-800">
            Access Portal
          </DialogTitle>
          <p className="text-gray-600 mt-2">Select your role to continue</p>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          {roles.map((role) => (
            <RoleCard
              key={role.key}
              icon={role.icon}
              title={role.title}
              description={role.description}
              color={role.color}
              onClick={() => handleRoleSelect(role.key)}
            />
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
